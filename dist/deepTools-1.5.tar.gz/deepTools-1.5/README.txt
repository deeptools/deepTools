========
deep tools
========

deep Tools provides useful routines to deal with mapped reads.
This includes converting them to bigwig files, run a 
GC correction and plot heatmaps and profiles.
